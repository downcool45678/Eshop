<?php

namespace App\Http\Controllers;
use App\Models\Post;
use Illuminate\Http\Request;


class Postcontroller extends Controller
{
        public function deletePost(Post $post)
        {
           
        if (auth()->user()->id === $post['user_id'])
        {
            $post->delete();
        }

        return redirect('/');

        }


    public function actuallyUpdatePost(Post $post,Request $request)

    {
        if (auth()->user()->id !== $post['user_id'])
        {
            return redirect('/');
        }

        $incomingFeilds = $request->validate([
            'title' => 'required',
            'body' =>'required'
        ]);

                 $incomingFeilds['title']=strip_tags($incomingFeilds['title']);
                 $incomingFeilds['body']=strip_tags($incomingFeilds['body']);

    $post->update($incomingFeilds);
    return redirect('/');
    }
 public function showEditScreens(Post $post) {
    if (auth()->user()->id !== $post['user_id'])
    {
        return redirect('/');
    }
    return view('edit-post',['post'=>$post]);
 }
    public function createPost(Request $request){
        $incomingFeilds=$request->validate([
        'title'=>'required',
        'body'=>'required'
    ]);

    $incomingFeilds['title']=strip_tags($incomingFeilds['title']);
    $incomingFeilds['body']=strip_tags($incomingFeilds['body']);
    $incomingFeilds['user_id']=auth()->id();
    Post::create($incomingFeilds);
    return redirect('/');
    }
}
