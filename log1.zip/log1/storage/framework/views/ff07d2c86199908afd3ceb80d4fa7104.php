<html>
<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        body {
          
            background-color: #014D4E;
        }

        .card {
            background-color: #FFF;
            border-radius: 10px;
        }

        .btn-primary {
            background-color: #009688;
            border-color: #009688;
        }

        .btn-primary:hover {
            background-color: #00796B;
            border-color: #00796B;
        }

        .btn-danger {
            background-color: #F44336;
            border-color: #F44336;
        }

        .btn-danger:hover {
            background-color: #D32F2F;
            border-color: #D32F2F;
        }

        .form-control {
            border-color: #009688;
        }

        .form-control:focus {
            border-color: #00796B;
            box-shadow: 0 0 0 0.2rem rgba(0, 150, 136, 0.25);
        }
    </style>
</head>
<body>
    <?php if(auth()->guard()->check()): ?>
    <div class="container mt-4">
        <div class="alert alert-success">
            Congrats, you're logged in!
        </div>
        <form action="/logout" method="POST">
            <?php echo csrf_field(); ?>
            <button class="btn btn-primary">Log Out</button>
        </form>

        <div class="card mt-4 p-4">
            <h2>Create a New Post</h2>
            <form action="/create-post" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <input type="text" name="title" class="form-control rounded-pill" placeholder="Title">
                </div>
                <div class="form-group">
                    <textarea name="body" class="form-control rounded" placeholder="Body content..."></textarea>
                </div>
                <button class="btn btn-primary">Save Post</button>
            </form>
        </div>

        <div class="card mt-4 p-4">
            <h2>All Posts</h2>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card bg-light mb-3">
                <div class="card-body">
                    <h3><?php echo e($post['title']); ?> by <?php echo e($post->user->name); ?></h3>
                    <?php echo e($post['body']); ?>

                    <p><a href="/edit-post/<?php echo e($post->id); ?>">Edit</a></p>
                    <form action="/delete-post/<?php echo e($post->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger">Delete</button>
                    </form>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <?php else: ?>

    <div class="container mt-4">
        <div class="card p-4  text-center">
        
            <h1>Register</h1>
            <form action="/register" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <input name="name" type="text" class="form-control rounded-pill" placeholder="Name">
                </div>
                <div class="form-group">
                    <input name="email" type="text" class="form-control rounded-pill" placeholder="Email">
                </div>
                <div class="form-group">
                    <input name="password" type="password" class="form-control rounded-pill" placeholder="Password">
                </div>
                <button class="btn btn-primary">Register</button>
            </form>
        </div>

        <div class="card mt-4 p-4 text-center">
            <h1>Login</h1>
            <form action="/login" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <input name="loginname" type="text" class="form-control rounded-pill" placeholder="Name">
                </div>
                <div class="form-group">
                    <input name="loginpassword" type="password" class="form-control rounded-pill" placeholder="Password">
                </div>
                <button class="btn btn-primary">Login</button>
            </form>
        </div>
    </div>

    <?php endif; ?>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
<?php /**PATH F:\laragon\www\log1\resources\views/home.blade.php ENDPATH**/ ?>