<html>
<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        body {
          
            background-color: #014D4E;
        }

        .card {
            background-color: #FFF;
            border-radius: 10px;
        }

        .btn-primary {
            background-color: #009688;
            border-color: #009688;
        }

        .btn-primary:hover {
            background-color: #00796B;
            border-color: #00796B;
        }

        .btn-danger {
            background-color: #F44336;
            border-color: #F44336;
        }

        .btn-danger:hover {
            background-color: #D32F2F;
            border-color: #D32F2F;
        }

        .form-control {
            border-color: #009688;
        }

        .form-control:focus {
            border-color: #00796B;
            box-shadow: 0 0 0 0.2rem rgba(0, 150, 136, 0.25);
        }
    </style>
</head>
<body>
    @auth
    <div class="container mt-4">
        <div class="alert alert-success">
            Congrats, you're logged in!
        </div>
        <form action="/logout" method="POST">
            @csrf
            <button class="btn btn-primary">Log Out</button>
        </form>

        <div class="card mt-4 p-4">
            <h2>Create a New Post</h2>
            <form action="/create-post" method="POST">
                @csrf
                <div class="form-group">
                    <input type="text" name="title" class="form-control rounded-pill" placeholder="Title">
                </div>
                <div class="form-group">
                    <textarea name="body" class="form-control rounded" placeholder="Body content..."></textarea>
                </div>
                <button class="btn btn-primary">Save Post</button>
            </form>
        </div>

        <div class="card mt-4 p-4">
            <h2>All Posts</h2>
            @foreach($posts as $post)
            <div class="card bg-light mb-3">
                <div class="card-body">
                    <h3>{{$post['title']}} by {{$post->user->name}}</h3>
                    {{$post['body']}}
                    <p><a href="/edit-post/{{$post->id}}">Edit</a></p>
                    <form action="/delete-post/{{$post->id}}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button class="btn btn-danger">Delete</button>
                    </form>
                </div>
            </div>
            @endforeach
        </div>
    </div>

    @else

    <div class="container mt-4">
        <div class="card p-4  text-center">
        
            <h1>Register</h1>
            <form action="/register" method="POST">
                @csrf
                <div class="form-group">
                    <input name="name" type="text" class="form-control rounded-pill" placeholder="Name">
                </div>
                <div class="form-group">
                    <input name="email" type="text" class="form-control rounded-pill" placeholder="Email">
                </div>
                <div class="form-group">
                    <input name="password" type="password" class="form-control rounded-pill" placeholder="Password">
                </div>
                <button class="btn btn-primary">Register</button>
            </form>
        </div>

        <div class="card mt-4 p-4 text-center">
            <h1>Login</h1>
            <form action="/login" method="POST">
                @csrf
                <div class="form-group">
                    <input name="loginname" type="text" class="form-control rounded-pill" placeholder="Name">
                </div>
                <div class="form-group">
                    <input name="loginpassword" type="password" class="form-control rounded-pill" placeholder="Password">
                </div>
                <button class="btn btn-primary">Login</button>
            </form>
        </div>
    </div>

    @endauth

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
