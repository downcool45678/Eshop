<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\Postcontroller;
use App\Models\User;
use App\Models\Post;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    $posts=[];
    if (auth()->check()){ 
    $posts =auth()->user()->usersCoolPosts()->latest()->get();
     }
    return view('home',['posts'=> $posts]);
});

Route::post('/register',[UserController::class ,'register']);
Route::post('/logout',[UserController::class ,'logout']);
Route::post('/login',[UserController::class ,'login']);
//blog post routes
Route::post('/create-post',[Postcontroller::class ,'createPost']);
Route::get('/edit-post/{post}',[Postcontroller::class ,'showEditScreens']);
Route::put('/edit-post/{post}',[Postcontroller::class ,'actuallyUpdatePost']);
Route::delete('/delete-post/{post}',[Postcontroller::class ,'deletePost']);


?>
